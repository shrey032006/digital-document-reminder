const mongoose = require('mongoose');

const CATEGORIES = [
  'Aadhaar',
  'PAN',
  'Passport',
  'Driving License',
  'Insurance',
  'Vehicle Registration',
  'Educational Certificate',
  'Other',
];

const documentSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    documentName: {
      type: String,
      required: [true, 'Document name is required'],
      trim: true,
      maxlength: 100,
    },
    documentNumber: {
      type: String,
      trim: true,
      maxlength: 100,
      default: '',
    },
    category: {
      type: String,
      enum: CATEGORIES,
      default: 'Other',
    },
    issueDate: {
      type: Date,
      default: null,
    },
    expiryDate: {
      type: Date,
      required: [true, 'Expiry date is required'],
    },
    filePath: {
      type: String,
      default: null,
    },
    // Persisted only so it can be filtered/sorted server-side; the source of
    // truth is always recomputed from expiryDate on every read/write.
    reminderStatus: {
      type: String,
      enum: ['Valid', 'Expiring Soon', 'Expired'],
      default: 'Valid',
    },
  },
  { timestamps: true }
);

documentSchema.statics.CATEGORIES = CATEGORIES;

// Recompute status any time the document is saved directly (create/update via .save()).
documentSchema.pre('save', function computeStatus(next) {
  this.reminderStatus = deriveStatus(this.expiryDate);
  next();
});

function deriveStatus(expiryDate) {
  if (!expiryDate) return 'Valid';
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  const daysLeft = Math.round((expiry - today) / (1000 * 60 * 60 * 24));
  if (daysLeft < 0) return 'Expired';
  if (daysLeft <= 30) return 'Expiring Soon';
  return 'Valid';
}

documentSchema.statics.deriveStatus = deriveStatus;

module.exports = mongoose.model('Document', documentSchema);
