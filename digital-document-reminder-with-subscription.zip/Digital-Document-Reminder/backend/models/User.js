const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: 60,
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Enter a valid email address'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: 6,
      select: false,
    },
    subscription: {
      plan: {
        type: String,
        enum: ['free', 'premium'],
        default: 'free',
      },
      // When a premium term expires the user simply reads back as 'free'
      // again (see isPremiumActive) — no cron job needed.
      premiumExpiresAt: {
        type: Date,
        default: null,
      },
      razorpayCustomerId: {
        type: String,
        default: null,
      },
    },
  },
  { timestamps: true }
);

// True only while an unexpired premium term is on the account.
userSchema.methods.isPremiumActive = function isPremiumActive() {
  return (
    this.subscription?.plan === 'premium' &&
    this.subscription?.premiumExpiresAt &&
    new Date(this.subscription.premiumExpiresAt) > new Date()
  );
};

// Hash password before saving, only when it has changed.
userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toSafeObject = function toSafeObject() {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    createdAt: this.createdAt,
    subscription: {
      plan: this.isPremiumActive() ? 'premium' : 'free',
      premiumExpiresAt: this.subscription?.premiumExpiresAt || null,
    },
  };
};

module.exports = mongoose.model('User', userSchema);
