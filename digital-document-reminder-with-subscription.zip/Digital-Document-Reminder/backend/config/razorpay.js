const Razorpay = require('razorpay');

let instance = null;

// Lazily created so the app can still boot (and every other feature still
// works) even if Razorpay keys haven't been configured yet — the
// subscription routes will just return a clear error until they are.
function getRazorpay() {
  if (instance) return instance;

  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;

  if (!key_id || !key_secret) {
    return null;
  }

  instance = new Razorpay({ key_id, key_secret });
  return instance;
}

module.exports = getRazorpay;
