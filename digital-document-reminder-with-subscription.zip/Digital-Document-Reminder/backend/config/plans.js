// Single source of truth for what Free vs Premium actually get.
// Keep this in sync with frontend/js/subscription.js's display copy.

module.exports = {
  FREE_DOCUMENT_LIMIT: 5,
  FREE_REMINDER_WINDOW_DAYS: 7, // free users only see the 7-day-out alert
  PREMIUM_REMINDER_WINDOWS_DAYS: [7, 15, 30],

  PREMIUM_PRICE_INR: 199, // ₹199 / year
  PREMIUM_DURATION_DAYS: 365,

  get PREMIUM_PRICE_PAISE() {
    return this.PREMIUM_PRICE_INR * 100;
  },
};
