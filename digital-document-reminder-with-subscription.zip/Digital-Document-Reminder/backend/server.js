require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const documentRoutes = require('./routes/documentRoutes');
const subscriptionRoutes = require('./routes/subscriptionRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();

// ---- Core middleware -------------------------------------------------------
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// ---- Uploaded files (photos/PDFs attached to documents) --------------------
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// ---- API routes -------------------------------------------------------------
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/subscription', subscriptionRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ---- Serve the frontend (plain HTML/CSS/JS) --------------------------------
const frontendDir = path.join(__dirname, '..', 'frontend');
app.use(express.static(frontendDir));

// Any non-API route falls back to index.html so direct links to e.g.
// /dashboard.html still resolve correctly when served from this same origin.
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(frontendDir, req.path === '/' ? 'index.html' : req.path), (err) => {
    if (err) next();
  });
});

// ---- Error handling -----------------------------------------------------
app.use(notFound);
app.use(errorHandler);

// ---- Start ---------------------------------------------------------------
const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Digital Document Reminder server running on http://localhost:${PORT}`);
  });
});

module.exports = app;
