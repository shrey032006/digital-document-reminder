const crypto = require('crypto');
const Document = require('../models/Document');
const Payment = require('../models/Payment');
const asyncHandler = require('../utils/asyncHandler');
const getRazorpay = require('../config/razorpay');
const {
  FREE_DOCUMENT_LIMIT,
  FREE_REMINDER_WINDOW_DAYS,
  PREMIUM_REMINDER_WINDOWS_DAYS,
  PREMIUM_PRICE_INR,
  PREMIUM_PRICE_PAISE,
  PREMIUM_DURATION_DAYS,
} = require('../config/plans');

// @route  GET /api/subscription/status
// @access Private
const getStatus = asyncHandler(async (req, res) => {
  const documentCount = await Document.countDocuments({ user: req.user._id });
  const isPremium = req.user.isPremiumActive();

  res.json({
    plan: isPremium ? 'premium' : 'free',
    premiumExpiresAt: req.user.subscription?.premiumExpiresAt || null,
    documentCount,
    documentLimit: isPremium ? null : FREE_DOCUMENT_LIMIT,
    reminderWindows: isPremium ? PREMIUM_REMINDER_WINDOWS_DAYS : [FREE_REMINDER_WINDOW_DAYS],
    pricing: { amount: PREMIUM_PRICE_INR, currency: 'INR', durationDays: PREMIUM_DURATION_DAYS },
  });
});

// @route  POST /api/subscription/create-order
// @access Private
const createOrder = asyncHandler(async (req, res) => {
  const razorpay = getRazorpay();
  if (!razorpay) {
    res.status(503);
    throw new Error('Payments are not configured on this server yet. Set RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET.');
  }

  if (req.user.isPremiumActive()) {
    res.status(400);
    throw new Error('You already have an active Premium subscription');
  }

  const order = await razorpay.orders.create({
    amount: PREMIUM_PRICE_PAISE,
    currency: 'INR',
    receipt: `ddr_${req.user._id}_${Date.now()}`,
    notes: { userId: String(req.user._id), plan: 'premium' },
  });

  await Payment.create({
    user: req.user._id,
    plan: 'premium',
    amount: PREMIUM_PRICE_INR,
    currency: 'INR',
    razorpayOrderId: order.id,
    status: 'created',
  });

  res.status(201).json({
    orderId: order.id,
    amount: order.amount,
    currency: order.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
});

// @route  POST /api/subscription/verify
// @body   { razorpay_order_id, razorpay_payment_id, razorpay_signature }
// @access Private
const verifyPayment = asyncHandler(async (req, res) => {
  const razorpay = getRazorpay();
  if (!razorpay) {
    res.status(503);
    throw new Error('Payments are not configured on this server yet.');
  }

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    res.status(400);
    throw new Error('Missing payment verification details');
  }

  const payment = await Payment.findOne({ razorpayOrderId: razorpay_order_id, user: req.user._id });
  if (!payment) {
    res.status(404);
    throw new Error('No matching order found for this payment');
  }

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    payment.status = 'failed';
    await payment.save();
    res.status(400);
    throw new Error('Payment verification failed — signature mismatch');
  }

  payment.status = 'paid';
  payment.razorpayPaymentId = razorpay_payment_id;
  await payment.save();

  // Extend from the current expiry if still active, otherwise from today.
  const base =
    req.user.subscription?.premiumExpiresAt && req.user.isPremiumActive()
      ? new Date(req.user.subscription.premiumExpiresAt)
      : new Date();
  const premiumExpiresAt = new Date(base.getTime() + PREMIUM_DURATION_DAYS * 24 * 60 * 60 * 1000);

  req.user.subscription.plan = 'premium';
  req.user.subscription.premiumExpiresAt = premiumExpiresAt;
  await req.user.save();

  res.json({ message: 'Payment verified — you are now on Premium', user: req.user.toSafeObject() });
});

// @route  GET /api/subscription/history
// @access Private
const getHistory = asyncHandler(async (req, res) => {
  const payments = await Payment.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json({ payments });
});

module.exports = { getStatus, createOrder, verifyPayment, getHistory };
