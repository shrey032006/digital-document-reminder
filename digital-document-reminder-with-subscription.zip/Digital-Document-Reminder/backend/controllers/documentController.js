const fs = require('fs');
const path = require('path');
const Document = require('../models/Document');
const asyncHandler = require('../utils/asyncHandler');
const { FREE_DOCUMENT_LIMIT } = require('../config/plans');

const removeFile = (filePath) => {
  if (!filePath) return;
  const absolute = path.join(__dirname, '..', '..', filePath);
  fs.unlink(absolute, (err) => {
    if (err && err.code !== 'ENOENT') {
      console.error('Failed to remove file:', absolute, err.message);
    }
  });
};

// Serialize a document with its live-computed reminder status + days left.
const withComputedStatus = (doc) => {
  const obj = doc.toObject ? doc.toObject() : doc;
  const status = Document.deriveStatus(obj.expiryDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(obj.expiryDate);
  expiry.setHours(0, 0, 0, 0);
  const daysLeft = Math.round((expiry - today) / (1000 * 60 * 60 * 24));
  return { ...obj, reminderStatus: status, daysLeft };
};

// @route  POST /api/documents
// @access Private
const createDocument = asyncHandler(async (req, res) => {
  const { documentName, documentNumber, category, issueDate, expiryDate } = req.body;

  if (!documentName || !expiryDate) {
    res.status(400);
    throw new Error('Document name and expiry date are required');
  }

  if (!req.user.isPremiumActive()) {
    const existingCount = await Document.countDocuments({ user: req.user._id });
    if (existingCount >= FREE_DOCUMENT_LIMIT) {
      res.status(403);
      throw new Error(
        `Free plan limit reached (${FREE_DOCUMENT_LIMIT} documents). Upgrade to Premium to add more.`
      );
    }
  }

  const document = await Document.create({
    user: req.user._id,
    documentName,
    documentNumber,
    category,
    issueDate: issueDate || null,
    expiryDate,
    filePath: req.file ? `/uploads/${req.file.filename}` : null,
  });

  res.status(201).json({ document: withComputedStatus(document) });
});

// @route  GET /api/documents
// @query  search, category, status (Valid|Expiring Soon|Expired), sort (expiryAsc|expiryDesc|nameAsc|nameDesc)
// @access Private
const getDocuments = asyncHandler(async (req, res) => {
  const { search, category, status, sort } = req.query;

  const query = { user: req.user._id };
  if (search) {
    query.$or = [
      { documentName: { $regex: search, $options: 'i' } },
      { documentNumber: { $regex: search, $options: 'i' } },
    ];
  }
  if (category) query.category = category;

  let documents = await Document.find(query);
  documents = documents.map(withComputedStatus);

  // Status is derived (not always in sync with the stored field), so filter after computing.
  if (status) {
    documents = documents.filter((d) => d.reminderStatus === status);
  }

  const sorters = {
    expiryAsc: (a, b) => new Date(a.expiryDate) - new Date(b.expiryDate),
    expiryDesc: (a, b) => new Date(b.expiryDate) - new Date(a.expiryDate),
    nameAsc: (a, b) => a.documentName.localeCompare(b.documentName),
    nameDesc: (a, b) => b.documentName.localeCompare(a.documentName),
    newest: (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
  };
  documents.sort(sorters[sort] || sorters.expiryAsc);

  res.json({ count: documents.length, documents });
});

// @route  GET /api/documents/summary
// @access Private
const getSummary = asyncHandler(async (req, res) => {
  const documents = (await Document.find({ user: req.user._id })).map(withComputedStatus);

  const summary = {
    total: documents.length,
    valid: documents.filter((d) => d.reminderStatus === 'Valid').length,
    expiringSoon: documents.filter((d) => d.reminderStatus === 'Expiring Soon').length,
    expired: documents.filter((d) => d.reminderStatus === 'Expired').length,
    expiringIn7Days: documents.filter((d) => d.daysLeft >= 0 && d.daysLeft <= 7).length,
    expiringIn15Days: documents.filter((d) => d.daysLeft >= 0 && d.daysLeft <= 15).length,
    expiringIn30Days: documents.filter((d) => d.daysLeft >= 0 && d.daysLeft <= 30).length,
  };

  const recent = [...documents]
    .sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate))
    .slice(0, 5);

  res.json({ summary, recent });
});

// @route  GET /api/documents/:id
// @access Private
const getDocumentById = asyncHandler(async (req, res) => {
  const document = await Document.findOne({ _id: req.params.id, user: req.user._id });
  if (!document) {
    res.status(404);
    throw new Error('Document not found');
  }
  res.json({ document: withComputedStatus(document) });
});

// @route  PUT /api/documents/:id
// @access Private
const updateDocument = asyncHandler(async (req, res) => {
  const document = await Document.findOne({ _id: req.params.id, user: req.user._id });
  if (!document) {
    res.status(404);
    throw new Error('Document not found');
  }

  const { documentName, documentNumber, category, issueDate, expiryDate } = req.body;
  if (documentName !== undefined) document.documentName = documentName;
  if (documentNumber !== undefined) document.documentNumber = documentNumber;
  if (category !== undefined) document.category = category;
  if (issueDate !== undefined) document.issueDate = issueDate || null;
  if (expiryDate !== undefined) document.expiryDate = expiryDate;

  if (req.file) {
    removeFile(document.filePath);
    document.filePath = `/uploads/${req.file.filename}`;
  } else if (req.body.removeFile === 'true') {
    removeFile(document.filePath);
    document.filePath = null;
  }

  await document.save();
  res.json({ document: withComputedStatus(document) });
});

// @route  DELETE /api/documents/:id
// @access Private
const deleteDocument = asyncHandler(async (req, res) => {
  const document = await Document.findOne({ _id: req.params.id, user: req.user._id });
  if (!document) {
    res.status(404);
    throw new Error('Document not found');
  }

  removeFile(document.filePath);
  await document.deleteOne();

  res.json({ message: 'Document deleted successfully' });
});

module.exports = {
  createDocument,
  getDocuments,
  getSummary,
  getDocumentById,
  updateDocument,
  deleteDocument,
};
