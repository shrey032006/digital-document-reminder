const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');

// @route  GET /api/users/profile
// @access Private
const getProfile = asyncHandler(async (req, res) => {
  res.json({ user: req.user.toSafeObject() });
});

// @route  PUT /api/users/profile
// @access Private
const updateProfile = asyncHandler(async (req, res) => {
  const { name, email } = req.body;

  if (email && email.toLowerCase() !== req.user.email) {
    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      res.status(400);
      throw new Error('That email is already in use by another account');
    }
    req.user.email = email.toLowerCase();
  }

  if (name) req.user.name = name;

  await req.user.save();
  res.json({ user: req.user.toSafeObject() });
});

// @route  PUT /api/users/change-password
// @access Private
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    res.status(400);
    throw new Error('Current and new password are required');
  }

  const user = await User.findById(req.user._id).select('+password');
  const matches = await user.comparePassword(currentPassword);
  if (!matches) {
    res.status(401);
    throw new Error('Current password is incorrect');
  }

  user.password = newPassword;
  await user.save();

  res.json({ message: 'Password updated successfully' });
});

module.exports = { getProfile, updateProfile, changePassword };
