const express = require('express');
const { getStatus, createOrder, verifyPayment, getHistory } = require('../controllers/subscriptionController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(protect);

router.get('/status', getStatus);
router.get('/history', getHistory);
router.post('/create-order', createOrder);
router.post('/verify', verifyPayment);

module.exports = router;
