const express = require('express');
const {
  createDocument,
  getDocuments,
  getSummary,
  getDocumentById,
  updateDocument,
  deleteDocument,
} = require('../controllers/documentController');
const { protect } = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

const router = express.Router();

router.use(protect);

router.get('/summary', getSummary);
router.route('/')
  .get(getDocuments)
  .post(upload.single('document'), createDocument);

router.route('/:id')
  .get(getDocumentById)
  .put(upload.single('document'), updateDocument)
  .delete(deleteDocument);

module.exports = router;
