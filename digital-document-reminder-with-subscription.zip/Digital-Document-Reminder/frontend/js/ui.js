/* ==========================================================================
   ui.js — toasts, confirm modal, navbar wiring, small formatters.
   Depends on api.js being loaded first (uses the global DDR object).
   ========================================================================== */

// ---- Toasts ----------------------------------------------------------------
function ensureToastStack() {
  let stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  return stack;
}

function toast(message, type = 'default') {
  const stack = ensureToastStack();
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity 0.2s';
    setTimeout(() => el.remove(), 200);
  }, 3200);
}

// ---- Confirm modal -----------------------------------------------------
function confirmModal({ title = 'Are you sure?', message = '', confirmLabel = 'Confirm', danger = true }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="icon-btn" data-close>✕</button>
        </div>
        <div class="modal-body">${message}</div>
        <div class="modal-footer">
          <button class="btn btn-outline" data-cancel>Cancel</button>
          <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-confirm>${confirmLabel}</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    const close = (result) => {
      overlay.remove();
      resolve(result);
    };

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close(false);
    });
    overlay.querySelector('[data-close]').addEventListener('click', () => close(false));
    overlay.querySelector('[data-cancel]').addEventListener('click', () => close(false));
    overlay.querySelector('[data-confirm]').addEventListener('click', () => close(true));
  });
}

// ---- Formatters --------------------------------------------------------
function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function toInputDate(value) {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString().slice(0, 10);
}

function initials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0].toUpperCase())
    .join('');
}

function statusBadgeHtml(status, daysLeft) {
  const map = {
    Valid: { cls: 'badge-valid', label: 'Valid' },
    'Expiring Soon': { cls: 'badge-expiring', label: typeof daysLeft === 'number' ? `Expires in ${daysLeft}d` : 'Expiring Soon' },
    Expired: { cls: 'badge-expired', label: typeof daysLeft === 'number' ? `Expired ${Math.abs(daysLeft)}d ago` : 'Expired' },
  };
  const cfg = map[status] || { cls: 'badge-neutral', label: status || 'Unknown' };
  return `<span class="badge ${cfg.cls}"><span class="badge-dot"></span>${cfg.label}</span>`;
}

const CATEGORY_ICONS = {
  Aadhaar: '🪪',
  PAN: '💳',
  Passport: '🛂',
  'Driving License': '🚘',
  Insurance: '🛡️',
  'Vehicle Registration': '🚗',
  'Educational Certificate': '🎓',
  Other: '📄',
};

function categoryIcon(category) {
  return CATEGORY_ICONS[category] || CATEGORY_ICONS.Other;
}

function debounce(fn, delay = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

function escapeHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ---- Navbar wiring -------------------------------------------------------
function initNavbar() {
  const toggle = document.querySelector('[data-nav-toggle]');
  const links = document.querySelector('[data-nav-links]');
  if (toggle && links) {
    toggle.addEventListener('click', () => links.classList.toggle('open'));
  }

  // Highlight current page link
  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('[data-nav-links] a').forEach((a) => {
    if (a.getAttribute('href') === current) a.classList.add('active');
  });

  // Populate user chip + wire logout, if present on this page
  const user = DDR.session.getUser();
  const chipName = document.querySelector('[data-user-name]');
  const chipAvatar = document.querySelector('[data-user-avatar]');
  if (user) {
    if (chipName) chipName.textContent = user.name;
    if (chipAvatar) chipAvatar.textContent = initials(user.name);
  }

  // Plan chip (Free/Premium) shown in the navbar — fetched fresh each load
  // so an upgrade on another tab/device is reflected without a stale cache.
  const planChip = document.querySelector('[data-plan-chip]');
  if (planChip && user) {
    DDR.api
      .getSubscriptionStatus()
      .then(({ plan }) => {
        planChip.textContent = plan === 'premium' ? '✨ Premium' : 'Free plan';
        planChip.classList.toggle('plan-chip-premium', plan === 'premium');
      })
      .catch(() => {
        planChip.remove();
      });
  }

  const logoutBtn = document.querySelector('[data-logout]');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      const ok = await confirmModal({
        title: 'Log out?',
        message: "You'll need to sign in again to access your documents.",
        confirmLabel: 'Log out',
      });
      if (ok) {
        DDR.session.clearSession();
        window.location.href = 'login.html';
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', initNavbar);
