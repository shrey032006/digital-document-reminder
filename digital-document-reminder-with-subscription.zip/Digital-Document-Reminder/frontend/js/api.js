/* ==========================================================================
   api.js — thin fetch wrapper + localStorage session helpers.
   Every other script relies on the DDR.api / DDR.session globals below.
   ========================================================================== */

const DDR = (() => {
  const API_BASE = '/api';
  const TOKEN_KEY = 'ddr_token';
  const USER_KEY = 'ddr_user';

  // ---- Session -----------------------------------------------------------
  const session = {
    getToken: () => localStorage.getItem(TOKEN_KEY),
    getUser: () => {
      try {
        const raw = localStorage.getItem(USER_KEY);
        return raw ? JSON.parse(raw) : null;
      } catch {
        return null;
      }
    },
    setSession: (user, token) => {
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    },
    updateUser: (user) => localStorage.setItem(USER_KEY, JSON.stringify(user)),
    clearSession: () => {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    },
    isAuthenticated: () => Boolean(localStorage.getItem(TOKEN_KEY)),
  };

  // Redirects to login if there's no token. Call at the top of every
  // protected page (dashboard, documents, addDocument, profile).
  const requireAuth = () => {
    if (!session.isAuthenticated()) {
      window.location.href = 'login.html';
    }
  };

  // Redirects away from login/register if already signed in.
  const redirectIfAuthed = () => {
    if (session.isAuthenticated()) {
      window.location.href = 'dashboard.html';
    }
  };

  // ---- API request ---------------------------------------------------------
  /**
   * @param {string} path        e.g. '/documents'
   * @param {object} [options]
   * @param {string} [options.method]
   * @param {object|FormData} [options.body]
   * @param {boolean} [options.isForm]  set true when body is a FormData instance
   */
  async function request(path, { method = 'GET', body, isForm = false } = {}) {
    const headers = {};
    const token = session.getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (body && !isForm) headers['Content-Type'] = 'application/json';

    let res;
    try {
      res = await fetch(`${API_BASE}${path}`, {
        method,
        headers,
        body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
      });
    } catch (networkErr) {
      throw new Error('Could not reach the server. Is the backend running?');
    }

    const isJson = (res.headers.get('content-type') || '').includes('application/json');
    const data = isJson ? await res.json().catch(() => ({})) : null;

    if (!res.ok) {
      if (res.status === 401) {
        session.clearSession();
        if (!location.pathname.endsWith('login.html') && !location.pathname.endsWith('register.html') && !location.pathname.endsWith('index.html') && location.pathname !== '/') {
          window.location.href = 'login.html';
        }
      }
      throw new Error((data && data.message) || `Request failed (${res.status})`);
    }

    return data;
  }

  const api = {
    // Auth
    register: (payload) => request('/auth/register', { method: 'POST', body: payload }),
    login: (payload) => request('/auth/login', { method: 'POST', body: payload }),

    // Profile
    getProfile: () => request('/users/profile'),
    updateProfile: (payload) => request('/users/profile', { method: 'PUT', body: payload }),
    changePassword: (payload) => request('/users/change-password', { method: 'PUT', body: payload }),

    // Documents
    getDocuments: (queryString = '') => request(`/documents${queryString}`),
    getSummary: () => request('/documents/summary'),
    getDocument: (id) => request(`/documents/${id}`),
    createDocument: (formData) => request('/documents', { method: 'POST', body: formData, isForm: true }),
    updateDocument: (id, formData) => request(`/documents/${id}`, { method: 'PUT', body: formData, isForm: true }),
    deleteDocument: (id) => request(`/documents/${id}`, { method: 'DELETE' }),

    // Subscription
    getSubscriptionStatus: () => request('/subscription/status'),
    getBillingHistory: () => request('/subscription/history'),
    createSubscriptionOrder: () => request('/subscription/create-order', { method: 'POST' }),
    verifySubscriptionPayment: (payload) => request('/subscription/verify', { method: 'POST', body: payload }),
  };

  return { api, session, requireAuth, redirectIfAuthed };
})();
