/* ==========================================================================
   dashboard.js
   ========================================================================== */

document.addEventListener('DOMContentLoaded', async () => {
  DDR.requireAuth();

  const user = DDR.session.getUser();
  const greetEl = document.getElementById('greeting');
  if (greetEl && user) {
    const hour = new Date().getHours();
    const time = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
    greetEl.textContent = `Good ${time}, ${user.name.split(' ')[0]}`;
  }

  const summaryGrid = document.getElementById('summary-grid');
  const recentList = document.getElementById('recent-list');
  const recentEmpty = document.getElementById('recent-empty');
  const upsellBanner = document.getElementById('upsell-banner');
  const upsellTitle = document.getElementById('upsell-title');
  const upsellSub = document.getElementById('upsell-sub');

  try {
    const { summary, recent } = await DDR.api.getSummary();
    renderSummary(summary);
    renderRecent(recent);
  } catch (err) {
    toast(err.message, 'error');
  }

  try {
    const status = await DDR.api.getSubscriptionStatus();
    renderUpsell(status);
  } catch {
    // Non-fatal — the rest of the dashboard still works without this.
  }

  function renderUpsell(status) {
    if (status.plan === 'premium') {
      upsellBanner.classList.add('hidden');
      return;
    }
    upsellBanner.classList.remove('hidden');
    const atLimit = status.documentCount >= status.documentLimit;
    upsellTitle.textContent = atLimit ? "You've reached the Free plan limit" : "You're on the Free plan";
    upsellSub.textContent = atLimit
      ? `You're using ${status.documentCount} of ${status.documentLimit} documents. Upgrade for unlimited storage and 15/30-day reminders.`
      : `${status.documentCount} of ${status.documentLimit} documents used · Premium unlocks unlimited documents and 15/30-day reminders.`;
  }

  function renderSummary(summary) {
    const cards = [
      { label: 'Total Documents', value: summary.total, icon: '📁', color: 'var(--primary-700)' },
      { label: 'Expiring Soon', value: summary.expiringSoon, icon: '⏰', color: 'var(--accent-500)' },
      { label: 'Expired', value: summary.expired, icon: '⚠️', color: 'var(--danger-600)' },
      { label: 'Valid', value: summary.valid, icon: '✅', color: 'var(--success-600)' },
    ];
    summaryGrid.innerHTML = cards
      .map(
        (c) => `
        <div class="card stat-card">
          <div>
            <p class="stat-label">${c.label}</p>
            <p class="stat-value">${c.value}</p>
          </div>
          <div class="stat-icon" style="background:${c.color}">${c.icon}</div>
        </div>`
      )
      .join('');

    const alertBar = document.getElementById('reminder-alert');
    if (alertBar) {
      if (summary.expiringIn7Days > 0 || summary.expired > 0) {
        alertBar.classList.remove('hidden');
        alertBar.innerHTML = `
          ⚡ You have <strong>${summary.expiringIn7Days}</strong> document(s) expiring within 7 days
          ${summary.expired > 0 ? `and <strong>${summary.expired}</strong> already expired.` : '.'}
          <a href="documents.html?status=Expiring%20Soon">Review now →</a>`;
      } else {
        alertBar.classList.add('hidden');
      }
    }
  }

  function renderRecent(recent) {
    if (!recent || recent.length === 0) {
      recentList.innerHTML = '';
      recentEmpty.classList.remove('hidden');
      return;
    }
    recentEmpty.classList.add('hidden');
    recentList.innerHTML = recent
      .map(
        (d) => `
        <div class="doc-row">
          <div class="flex gap-12" style="align-items:center;">
            <div class="doc-icon">${categoryIcon(d.category)}</div>
            <div>
              <p class="doc-title">${escapeHtml(d.documentName)}</p>
              <p class="doc-meta">${escapeHtml(d.category)} · Expires ${formatDate(d.expiryDate)}</p>
            </div>
          </div>
          ${statusBadgeHtml(d.reminderStatus, d.daysLeft)}
        </div>`
      )
      .join('');
  }
});
