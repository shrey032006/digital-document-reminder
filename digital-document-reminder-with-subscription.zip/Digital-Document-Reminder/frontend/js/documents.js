/* ==========================================================================
   documents.js
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  DDR.requireAuth();

  const tableBody = document.getElementById('doc-table-body');
  const tableWrap = document.getElementById('table-wrap');
  const emptyState = document.getElementById('doc-empty');
  const spinner = document.getElementById('doc-spinner');
  const resultCount = document.getElementById('result-count');

  const searchInput = document.getElementById('search-input');
  const categoryFilter = document.getElementById('category-filter');
  const statusFilter = document.getElementById('status-filter');
  const sortSelect = document.getElementById('sort-select');

  // Pre-fill filters from query string (e.g. dashboard "Review now" link).
  const params = new URLSearchParams(location.search);
  if (params.get('status')) statusFilter.value = params.get('status');
  if (params.get('category')) categoryFilter.value = params.get('category');

  const buildQuery = () => {
    const q = new URLSearchParams();
    if (searchInput.value.trim()) q.set('search', searchInput.value.trim());
    if (categoryFilter.value) q.set('category', categoryFilter.value);
    if (statusFilter.value) q.set('status', statusFilter.value);
    if (sortSelect.value) q.set('sort', sortSelect.value);
    const str = q.toString();
    return str ? `?${str}` : '';
  };

  async function loadDocuments() {
    spinner.classList.remove('hidden');
    tableWrap.classList.add('hidden');
    emptyState.classList.add('hidden');

    try {
      const { documents, count } = await DDR.api.getDocuments(buildQuery());
      resultCount.textContent = `${count} document${count === 1 ? '' : 's'} found`;
      if (count === 0) {
        emptyState.classList.remove('hidden');
      } else {
        tableWrap.classList.remove('hidden');
        renderRows(documents);
      }
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      spinner.classList.add('hidden');
    }
  }

  function renderRows(documents) {
    tableBody.innerHTML = documents
      .map(
        (d) => `
        <tr>
          <td>
            <div class="flex gap-12" style="align-items:center;">
              <div class="doc-icon">${categoryIcon(d.category)}</div>
              <div>
                <p class="doc-title">${escapeHtml(d.documentName)}</p>
                ${d.documentNumber ? `<p class="doc-meta">${escapeHtml(d.documentNumber)}</p>` : ''}
              </div>
            </div>
          </td>
          <td>${escapeHtml(d.category)}</td>
          <td>${formatDate(d.issueDate)}</td>
          <td>${formatDate(d.expiryDate)}</td>
          <td>${statusBadgeHtml(d.reminderStatus, d.daysLeft)}</td>
          <td>
            <div class="table-actions">
              ${d.filePath ? `<a class="icon-btn" href="${d.filePath}" target="_blank" title="View file">📎</a>` : ''}
              <a class="icon-btn" href="addDocument.html?id=${d._id}" title="Edit">✏️</a>
              <button class="icon-btn danger" data-delete="${d._id}" title="Delete">🗑️</button>
            </div>
          </td>
        </tr>`
      )
      .join('');

    tableBody.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => handleDelete(btn.dataset.delete));
    });
  }

  async function handleDelete(id) {
    const ok = await confirmModal({
      title: 'Delete this document?',
      message: 'This will permanently remove the record and any uploaded file. This cannot be undone.',
      confirmLabel: 'Delete',
    });
    if (!ok) return;

    try {
      await DDR.api.deleteDocument(id);
      toast('Document deleted', 'success');
      loadDocuments();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  searchInput.addEventListener('input', debounce(loadDocuments, 300));
  categoryFilter.addEventListener('change', loadDocuments);
  statusFilter.addEventListener('change', loadDocuments);
  sortSelect.addEventListener('change', loadDocuments);

  loadDocuments();
});
