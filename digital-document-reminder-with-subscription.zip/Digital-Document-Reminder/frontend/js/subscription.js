/* ==========================================================================
   subscription.js — plan status, usage bar, Razorpay upgrade flow, billing history.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', async () => {
  DDR.requireAuth();

  const currentPlanLabel = document.getElementById('current-plan-label');
  const currentPlanSub = document.getElementById('current-plan-sub');
  const usageCount = document.getElementById('usage-count');
  const usageLimit = document.getElementById('usage-limit');
  const usageBar = document.getElementById('usage-bar');
  const freeCard = document.getElementById('free-plan-card');
  const premiumCard = document.getElementById('premium-plan-card');
  const premiumPrice = document.getElementById('premium-price');
  const upgradeBtn = document.getElementById('upgrade-btn');
  const billingList = document.getElementById('billing-list');
  const billingEmpty = document.getElementById('billing-empty');

  await loadStatus();
  await loadHistory();

  async function loadStatus() {
    try {
      const status = await DDR.api.getSubscriptionStatus();
      renderStatus(status);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  function renderStatus(status) {
    const isPremium = status.plan === 'premium';

    currentPlanLabel.textContent = isPremium ? '✨ Premium' : 'Free';
    currentPlanSub.textContent = isPremium
      ? `Renews / expires on ${formatDate(status.premiumExpiresAt)}`
      : 'Upgrade any time to unlock unlimited documents and longer reminder windows.';

    const limit = status.documentLimit; // null when premium (unlimited)
    usageCount.textContent = status.documentCount;
    usageLimit.textContent = limit === null ? '∞' : limit;
    const pct = limit === null ? Math.min((status.documentCount / 10) * 100, 100) : Math.min((status.documentCount / limit) * 100, 100);
    usageBar.style.width = `${pct}%`;
    usageBar.classList.toggle('at-limit', limit !== null && status.documentCount >= limit);

    premiumPrice.innerHTML = `₹${status.pricing.amount} <span>/ year</span>`;

    if (isPremium) {
      freeCard.querySelector('button').textContent = 'Included';
      premiumCard.querySelector('.pricing-badge').textContent = 'Active';
      upgradeBtn.textContent = 'Currently active';
      upgradeBtn.disabled = true;
      upgradeBtn.classList.remove('btn-primary');
      upgradeBtn.classList.add('btn-outline');
    } else {
      freeCard.querySelector('button').textContent = 'Your current plan';
    }
  }

  async function loadHistory() {
    try {
      const { payments } = await DDR.api.getBillingHistory();
      renderHistory(payments);
    } catch (err) {
      // Non-fatal — billing history is a nice-to-have on this page.
      billingEmpty.classList.remove('hidden');
    }
  }

  function renderHistory(payments) {
    if (!payments || payments.length === 0) {
      billingList.innerHTML = '';
      billingEmpty.classList.remove('hidden');
      return;
    }
    billingEmpty.classList.add('hidden');
    billingList.innerHTML = payments
      .map((p) => {
        const statusCls = p.status === 'paid' ? 'badge-valid' : p.status === 'failed' ? 'badge-expired' : 'badge-neutral';
        return `
        <div class="doc-row">
          <div>
            <p class="doc-title">Premium subscription — ₹${p.amount}</p>
            <p class="doc-meta">${formatDate(p.createdAt)} · Order ${escapeHtml(p.razorpayOrderId)}</p>
          </div>
          <span class="badge ${statusCls}"><span class="badge-dot"></span>${escapeHtml(p.status)}</span>
        </div>`;
      })
      .join('');
  }

  upgradeBtn.addEventListener('click', async () => {
    if (typeof Razorpay === 'undefined') {
      toast('Payment SDK failed to load. Check your connection and try again.', 'error');
      return;
    }

    upgradeBtn.disabled = true;
    upgradeBtn.textContent = 'Starting checkout…';

    try {
      const order = await DDR.api.createSubscriptionOrder();
      const user = DDR.session.getUser();

      const rzp = new Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        order_id: order.orderId,
        name: 'Digital Document Reminder',
        description: 'Premium subscription — 1 year',
        prefill: { name: user?.name || '', email: user?.email || '' },
        theme: { color: '#0F766E' },
        handler: async (response) => {
          try {
            const { user: updatedUser } = await DDR.api.verifySubscriptionPayment({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            DDR.session.updateUser(updatedUser);
            toast('Payment verified — welcome to Premium!', 'success');
            setTimeout(() => window.location.reload(), 600);
          } catch (err) {
            toast(err.message, 'error');
            resetUpgradeBtn();
          }
        },
        modal: {
          ondismiss: () => resetUpgradeBtn(),
        },
      });

      rzp.on('payment.failed', () => {
        toast('Payment failed. Please try again.', 'error');
        resetUpgradeBtn();
      });

      rzp.open();
    } catch (err) {
      toast(err.message, 'error');
      resetUpgradeBtn();
    }
  });

  function resetUpgradeBtn() {
    upgradeBtn.disabled = false;
    upgradeBtn.textContent = 'Upgrade to Premium';
  }
});
