/* ==========================================================================
   profile.js
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  DDR.requireAuth();

  const user = DDR.session.getUser();
  const profileForm = document.getElementById('profile-form');
  const passwordForm = document.getElementById('password-form');
  const avatarEl = document.getElementById('profile-avatar');
  const nameHeading = document.getElementById('profile-name-heading');
  const emailSub = document.getElementById('profile-email-sub');

  if (user) {
    profileForm.name.value = user.name;
    profileForm.email.value = user.email;
    avatarEl.textContent = initials(user.name);
    nameHeading.textContent = user.name;
    emailSub.textContent = user.email;
  }

  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = profileForm.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Saving…';

    try {
      const { user: updated } = await DDR.api.updateProfile({
        name: profileForm.name.value.trim(),
        email: profileForm.email.value.trim(),
      });
      DDR.session.updateUser(updated);
      avatarEl.textContent = initials(updated.name);
      nameHeading.textContent = updated.name;
      emailSub.textContent = updated.email;
      toast('Profile updated successfully', 'success');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Save changes';
    }
  });

  passwordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const { currentPassword, newPassword, confirmPassword } = passwordForm;

    if (newPassword.value.length < 6) {
      return toast('New password must be at least 6 characters', 'error');
    }
    if (newPassword.value !== confirmPassword.value) {
      return toast('New passwords do not match', 'error');
    }

    const btn = passwordForm.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Updating…';

    try {
      await DDR.api.changePassword({
        currentPassword: currentPassword.value,
        newPassword: newPassword.value,
      });
      toast('Password updated successfully', 'success');
      passwordForm.reset();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Update password';
    }
  });

  const logoutBtnSession = document.getElementById('logout-everywhere');
  if (logoutBtnSession) {
    logoutBtnSession.addEventListener('click', async () => {
      const ok = await confirmModal({
        title: 'Log out?',
        message: 'You will need to sign in again on this device.',
        confirmLabel: 'Log out',
      });
      if (ok) {
        DDR.session.clearSession();
        window.location.href = 'login.html';
      }
    });
  }
});
