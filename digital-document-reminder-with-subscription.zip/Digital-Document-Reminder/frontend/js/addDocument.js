/* ==========================================================================
   addDocument.js — handles both "add" and "edit" (?id=...) modes.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  DDR.requireAuth();

  const form = document.getElementById('document-form');
  const pageTitle = document.getElementById('form-title');
  const pageSub = document.getElementById('form-subtitle');
  const submitBtn = document.getElementById('submit-btn');
  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('file-input');
  const dzDefault = document.getElementById('dz-default');
  const dzFile = document.getElementById('dz-file');
  const dzFileName = document.getElementById('dz-file-name');
  const dzRemove = document.getElementById('dz-remove');
  const existingFileNote = document.getElementById('existing-file-note');

  const params = new URLSearchParams(location.search);
  const editId = params.get('id');
  let selectedFile = null;
  let removedExistingFile = false;

  if (editId) {
    pageTitle.textContent = 'Edit Document';
    pageSub.textContent = 'Update the details below and save your changes.';
    submitBtn.textContent = 'Save Changes';
    loadExisting(editId);
  }

  async function loadExisting(id) {
    try {
      const { document: doc } = await DDR.api.getDocument(id);
      form.documentName.value = doc.documentName || '';
      form.documentNumber.value = doc.documentNumber || '';
      form.category.value = doc.category || 'Other';
      form.issueDate.value = toInputDate(doc.issueDate);
      form.expiryDate.value = toInputDate(doc.expiryDate);
      if (doc.filePath) {
        existingFileNote.classList.remove('hidden');
        existingFileNote.querySelector('a').href = doc.filePath;
      }
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  // ---- Dropzone -----------------------------------------------------------
  dropzone.addEventListener('click', () => fileInput.click());
  dropzone.addEventListener('dragover', (e) => { e.preventDefault(); dropzone.classList.add('dragover'); });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files[0]) setFile(fileInput.files[0]);
  });
  dzRemove.addEventListener('click', (e) => {
    e.stopPropagation();
    selectedFile = null;
    removedExistingFile = true;
    fileInput.value = '';
    dzDefault.classList.remove('hidden');
    dzFile.classList.add('hidden');
    existingFileNote.classList.add('hidden');
  });

  function setFile(file) {
    const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
    if (!allowed.includes(file.type)) {
      toast('Only PDF, JPG or PNG files are allowed', 'error');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast('File must be smaller than 5MB', 'error');
      return;
    }
    selectedFile = file;
    removedExistingFile = false;
    dzFileName.textContent = `${file.name} (${(file.size / 1024).toFixed(0)} KB)`;
    dzDefault.classList.add('hidden');
    dzFile.classList.remove('hidden');
  }

  // ---- Submit ---------------------------------------------------------------
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!form.documentName.value.trim()) return toast('Document name is required', 'error');
    if (!form.expiryDate.value) return toast('Expiry date is required', 'error');

    const formData = new FormData();
    formData.append('documentName', form.documentName.value.trim());
    formData.append('documentNumber', form.documentNumber.value.trim());
    formData.append('category', form.category.value);
    formData.append('issueDate', form.issueDate.value);
    formData.append('expiryDate', form.expiryDate.value);
    if (selectedFile) formData.append('document', selectedFile);
    if (removedExistingFile && !selectedFile) formData.append('removeFile', 'true');

    submitBtn.disabled = true;
    submitBtn.textContent = editId ? 'Saving…' : 'Saving…';

    try {
      if (editId) {
        await DDR.api.updateDocument(editId, formData);
        toast('Document updated successfully', 'success');
      } else {
        await DDR.api.createDocument(formData);
        toast('Document added successfully', 'success');
      }
      setTimeout(() => (window.location.href = 'documents.html'), 500);
    } catch (err) {
      toast(err.message, 'error');
      if (/Free plan limit reached/i.test(err.message)) {
        setTimeout(() => (window.location.href = 'subscription.html'), 1400);
      }
      submitBtn.disabled = false;
      submitBtn.textContent = editId ? 'Save Changes' : 'Add Document';
    }
  });
});
