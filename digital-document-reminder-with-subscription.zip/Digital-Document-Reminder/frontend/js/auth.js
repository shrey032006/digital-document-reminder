/* ==========================================================================
   auth.js — handles both login.html and register.html forms.
   ========================================================================== */

function setFieldError(field, message) {
  const wrap = field.closest('.field');
  if (!wrap) return;
  wrap.classList.toggle('has-error', Boolean(message));
  let errEl = wrap.querySelector('.field-error');
  if (message) {
    if (!errEl) {
      errEl = document.createElement('p');
      errEl.className = 'field-error';
      wrap.appendChild(errEl);
    }
    errEl.textContent = message;
  } else if (errEl) {
    errEl.remove();
  }
}

function clearFieldErrors(form) {
  form.querySelectorAll('.field-error').forEach((el) => el.remove());
  form.querySelectorAll('.field.has-error').forEach((el) => el.classList.remove('has-error'));
}

function wirePasswordToggle(scope = document) {
  scope.querySelectorAll('[data-toggle-password]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.togglePassword);
      if (!input) return;
      const isPw = input.type === 'password';
      input.type = isPw ? 'text' : 'password';
      btn.textContent = isPw ? '🙈' : '👁️';
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  DDR.redirectIfAuthed();
  wirePasswordToggle();

  // ---- Login form --------------------------------------------------------
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearFieldErrors(loginForm);

      const email = loginForm.email.value.trim();
      const password = loginForm.password.value;

      if (!email) return setFieldError(loginForm.email, 'Email is required');
      if (!password) return setFieldError(loginForm.password, 'Password is required');

      const btn = loginForm.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Signing in…';

      try {
        const { user, token } = await DDR.api.login({ email, password });
        DDR.session.setSession(user, token);
        toast(`Welcome back, ${user.name.split(' ')[0]}!`, 'success');
        setTimeout(() => (window.location.href = 'dashboard.html'), 400);
      } catch (err) {
        toast(err.message, 'error');
        btn.disabled = false;
        btn.textContent = 'Sign in';
      }
    });
  }

  // ---- Register form ------------------------------------------------------
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearFieldErrors(registerForm);

      const name = registerForm.name.value.trim();
      const email = registerForm.email.value.trim();
      const password = registerForm.password.value;
      const confirmPassword = registerForm.confirmPassword.value;

      let valid = true;
      if (name.length < 2) { setFieldError(registerForm.name, 'Enter your full name'); valid = false; }
      if (!/^\S+@\S+\.\S+$/.test(email)) { setFieldError(registerForm.email, 'Enter a valid email'); valid = false; }
      if (password.length < 6) { setFieldError(registerForm.password, 'Password must be at least 6 characters'); valid = false; }
      if (confirmPassword !== password) { setFieldError(registerForm.confirmPassword, 'Passwords do not match'); valid = false; }
      if (!registerForm.agree.checked) { toast('Please accept the terms to continue', 'error'); valid = false; }
      if (!valid) return;

      const btn = registerForm.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Creating account…';

      try {
        const { user, token } = await DDR.api.register({ name, email, password });
        DDR.session.setSession(user, token);
        toast('Account created successfully!', 'success');
        setTimeout(() => (window.location.href = 'dashboard.html'), 400);
      } catch (err) {
        toast(err.message, 'error');
        btn.disabled = false;
        btn.textContent = 'Create account';
      }
    });
  }
});
