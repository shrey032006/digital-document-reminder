# Digital Document Reminder System

A full-stack mini project that helps users securely store important document
details (Aadhaar, PAN, Passport, Driving License, Insurance, Vehicle
Registration, Educational Certificates, etc.) and reminds them before those
documents expire.

## Tech stack

- **Frontend:** HTML, CSS, vanilla JavaScript (no framework/build step)
- **Backend:** Node.js, Express.js
- **Database:** MongoDB (via Mongoose)
- **Auth:** JWT (JSON Web Tokens) + bcrypt password hashing
- **File uploads:** Multer (PDF/JPG/PNG, up to 5MB per document)

## Features

- User registration & login (hashed passwords, JWT sessions)
- Add / edit / delete / view documents, with optional file attachment
- Dashboard summary: total, valid, expiring soon, and expired documents
- Reminder logic: flags documents expiring within 7 / 15 / 30 days
- Search by name/number, filter by category or status, sort by expiry/name
- Profile management: update name/email, change password
- **Subscription plans:** Free (5 documents, 7-day reminder) vs Premium
  (unlimited documents, 7/15/30-day reminder windows) with Razorpay checkout,
  a plan chip in the navbar, a usage bar, and billing history

## Project structure

```
Digital-Document-Reminder/
├── frontend/
│   ├── index.html          landing page
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── documents.html      full list — search, filter, sort, edit/delete
│   ├── addDocument.html    add AND edit (edit via ?id=<documentId>)
│   ├── profile.html        profile + change password
│   ├── subscription.html   plan comparison, usage, upgrade, billing history
│   ├── css/style.css
│   └── js/
│       ├── api.js          fetch wrapper + localStorage session helpers
│       ├── ui.js           toasts, confirm modal, navbar wiring, formatters
│       ├── auth.js         login/register form logic
│       ├── dashboard.js
│       ├── documents.js
│       ├── addDocument.js
│       ├── profile.js
│       └── subscription.js Razorpay checkout + plan status
│
├── backend/
│   ├── server.js
│   ├── routes/            authRoutes, userRoutes, documentRoutes, subscriptionRoutes
│   ├── controllers/       authController, userController, documentController,
│   │                       subscriptionController
│   ├── models/            User.js, Document.js, Payment.js
│   ├── middleware/        authMiddleware, uploadMiddleware, errorMiddleware
│   ├── config/             db.js, plans.js, razorpay.js
│   └── utils/              generateToken, asyncHandler
│
├── uploads/                 uploaded document files land here
├── package.json
├── .env.example
└── README.md
```

> Note: the original brief listed only `index.html`, `login.html`,
> `register.html`, `dashboard.html` and `addDocument.html` under `frontend/`.
> I added `documents.html` and `profile.html` since the feature list
> explicitly calls for "View All Documents / Search Documents" and "Profile
> Management" as their own modules — everything else follows the structure
> exactly as specified.

## Getting started

**Requirements:** Node.js 18+, MongoDB running locally (or a MongoDB Atlas
connection string).

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# then edit .env — at minimum set MONGO_URI and JWT_SECRET
# for the subscription feature, also set RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET
# (free test-mode keys from https://dashboard.razorpay.com → Settings → API Keys)

# 3. Start MongoDB locally if you're not using Atlas
mongod

# 4. Run the server (serves both the API and the frontend)
npm run dev      # with nodemon, auto-restarts on change
# or
npm start
```

> Without Razorpay keys, everything else in the app still works — the
> subscription routes just return a `503` until you set them.

Then open **http://localhost:5000** in your browser — the Express server
serves the static frontend directly, so there's nothing extra to run on the
frontend side.

## How it works

1. A user registers (`POST /api/auth/register`) or logs in
   (`POST /api/auth/login`); the server returns a JWT which the frontend
   stores in `localStorage` and sends as `Authorization: Bearer <token>` on
   every subsequent request.
2. Documents are created via `POST /api/documents` (multipart form, optional
   file field named `document`), scoped to the logged-in user.
3. Every read recomputes each document's reminder status from its
   `expiryDate` (`Valid` / `Expiring Soon` ≤30 days / `Expired`), so the
   dashboard and list are always accurate without a separate cron job.
4. `GET /api/documents/summary` powers the dashboard cards and surfaces
   documents expiring within 7/15/30 days for the reminder banner.
5. Editing a document reuses `addDocument.html` — visiting it with
   `?id=<documentId>` pre-fills the form and switches it into edit mode.

## API reference

| Method | Route                        | Auth | Description                          |
|--------|-------------------------------|------|---------------------------------------|
| POST   | `/api/auth/register`          | —    | Create an account                    |
| POST   | `/api/auth/login`             | —    | Sign in, returns `{ user, token }`   |
| GET    | `/api/users/profile`          | ✅   | Get current user                     |
| PUT    | `/api/users/profile`          | ✅   | Update name/email                    |
| PUT    | `/api/users/change-password`  | ✅   | Change password                      |
| GET    | `/api/documents`               | ✅   | List documents (`?search=&category=&status=&sort=`) |
| GET    | `/api/documents/summary`      | ✅   | Dashboard counts + upcoming list     |
| GET    | `/api/documents/:id`           | ✅   | Get one document                     |
| POST   | `/api/documents`               | ✅   | Create (multipart, field `document`) |
| PUT    | `/api/documents/:id`           | ✅   | Update (optionally replace file)     |
| DELETE | `/api/documents/:id`           | ✅   | Delete document + its file           |

## Future enhancements

Email/SMS reminders, cloud file storage, OCR-based auto-fill, a native mobile
app, multi-language support, and Google Calendar integration — see the
original project brief for the full list.
